# made_comp
Admission test for Data Analyst School MADE

![kaggle](imgs/kaggle_kek.png)

| compititon | link |score|
| ------------- | ------------- |----------------|
| comp_1 | https://cups.mail.ru/tasks/1034 |![score1](imgs/score_task_1.png)|
| comp_2  | https://cups.mail.ru/tasks/1035 |![score2](imgs/score_task_2.png)|
